using System;

class PC{

  string modelo;
  int ram = 8;
  int armazenamento = 512;
  double cpuClock;
  bool videoDedicado = true;
  bool estaLigado = false;

  public PC(string modelo, double cpuClock){
    this.modelo = modelo;
    this.cpuClock = cpuClock;
  }

  public void Ligar()
  {
    this.estaLigado = true;
    Console.WriteLine("PC ligado");
  }

  public void Desligar(){
    this.estaLigado = false;
    
  }
  
}